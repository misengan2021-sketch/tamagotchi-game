package com.example.tamagotchi.notifications

import android.content.Context
import androidx.work.*
import com.example.tamagotchi.model.Pet
import com.google.gson.Gson
import java.util.concurrent.TimeUnit

object ReminderScheduler {

    fun schedule(context: Context, pet: Pet) {
        cancel(context, pet.id)

        if (pet.reminderHours <= 0) return

        val data = workDataOf(
            "pet_json" to Gson().toJson(pet),
        )

        val request = PeriodicWorkRequestBuilder<PetReminderWorker>(
            pet.reminderHours.toLong(),
            TimeUnit.HOURS
        )
            .setInputData(data)
            .build()

        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(
                "reminder_${'$'}{pet.id}",
                ExistingPeriodicWorkPolicy.REPLACE,
                request
            )
    }

    fun cancel(context: Context, petId: String) {
        WorkManager.getInstance(context).cancelUniqueWork("reminder_${'$'}{petId}")
    }
}
