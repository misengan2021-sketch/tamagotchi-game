package com.example.tamagotchi.notifications

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.tamagotchi.model.Pet
import com.google.gson.Gson

class PetReminderWorker(
    ctx: Context,
    params: WorkerParameters
) : Worker(ctx, params) {

    override fun doWork(): Result {
        val json = inputData.getString("pet_json") ?: return Result.failure()
        val pet = Gson().fromJson(json, Pet::class.java) ?: return Result.failure()

        NotificationHelper.createChannel(applicationContext)
        NotificationHelper.showNotification(
            applicationContext,
            pet.id.hashCode(),
            "${'$'}{pet.name} ждёт тебя",
            if (pet.hunger < 50) "Покорми меня!" else "Поиграй со мной!"
        )

        return Result.success()
    }
}
