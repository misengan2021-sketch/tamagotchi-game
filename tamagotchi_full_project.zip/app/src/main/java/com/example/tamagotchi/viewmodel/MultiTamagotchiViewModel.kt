package com.example.tamagotchi.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.tamagotchi.data.PetsRepository
import com.example.tamagotchi.data.ShopRepository
import com.example.tamagotchi.model.*
import com.example.tamagotchi.util.AppearanceGenerator
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.*
import kotlin.random.Random
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf

class MultiTamagotchiViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = PetsRepository(application.applicationContext)

    private val _pets = mutableStateListOf<Pet>()
    val pets: List<Pet> get() = _pets

    private val _selectedIndex = mutableStateOf(0)
    val selectedIndex get() = _selectedIndex.value
    val selectedPet get() = _pets.getOrNull(selectedIndex)

    init {
        val loaded = repo.loadAll()
        if (loaded.isEmpty()) {
            val p = Pet(
                id = UUID.randomUUID().toString(),
                personality = Personality.PLAYFUL,
                appearance = AppearanceGenerator.generate(Personality.PLAYFUL)
            )
            _pets.add(p)
            repo.saveAll(_pets)
        } else {
            _pets.addAll(loaded)
        }
        startTicker()
    }

    private var tickMs = 3000L
    private fun startTicker() {
        viewModelScope.launch {
            while (true) {
                delay(tickMs)
                for (i in _pets.indices) {
                    val p = _pets[i]
                    if (!p.alive) continue
                    val newHunger = (p.hunger - 2).coerceIn(0, 100)
                    val newEnergy = (p.energy - 1).coerceIn(0, 100)
                    val newHappiness = (p.happiness - 1).coerceIn(0,100)
                    val newAge = p.ageSeconds + tickMs / 1000
                    val alive = newHunger > 0 && newEnergy > 0
                    _pets[i] = p.copy(hunger=newHunger, energy=newEnergy, happiness=newHappiness, ageSeconds=newAge, alive=alive)
                }
                repo.saveAll(_pets)
            }
        }
    }

    fun feedSelected() {
        val idx = selectedIndex
        if (idx !in _pets.indices) return
        val p = _pets[idx]
        if (!p.alive) return
        _pets[idx] = p.copy(hunger = (p.hunger + 20).coerceAtMost(100), happiness = (p.happiness + 5).coerceAtMost(100))
        addXPToSelected(5)
        repo.saveAll(_pets)
    }

    fun playSelected() {
        val idx = selectedIndex
        if (idx !in _pets.indices) return
        val p = _pets[idx]
        if (!p.alive) return
        _pets[idx] = p.copy(happiness = (p.happiness + 15).coerceAtMost(100), energy = (p.energy - 10).coerceAtLeast(0))
        addXPToSelected(7)
        repo.saveAll(_pets)
    }

    fun buyItem(item: ShopItem) {
        val idx = selectedIndex
        if (idx !in _pets.indices) return
        val p = _pets[idx]
        if (p.coins < item.price) return
        _pets[idx] = p.copy(coins = p.coins - item.price,
            hunger = (p.hunger + item.hungerRestore).coerceAtMost(100),
            happiness = (p.happiness + item.happinessBoost).coerceAtMost(100))
        repo.saveAll(_pets)
    }

    fun addXPToSelected(amount: Int) {
        val idx = selectedIndex
        if (idx !in _pets.indices) return
        var p = _pets[idx]
        val newXp = p.xp + amount
        var level = p.level
        var coins = p.coins
        val required = 50 + level * 20
        if (newXp >= required) {
            level += 1
            coins += 10 * level
            _pets[idx] = p.copy(xp = newXp - required, level = level, coins = coins)
        } else {
            _pets[idx] = p.copy(xp = newXp)
        }
        repo.saveAll(_pets)
    }

    fun exportJson(): String = repo.exportJson(_pets)
    fun importJson(json: String): List<Pet> {
        val merged = repo.importFromJson(json)
        _pets.clear()
        _pets.addAll(merged)
        return merged
    }
}
