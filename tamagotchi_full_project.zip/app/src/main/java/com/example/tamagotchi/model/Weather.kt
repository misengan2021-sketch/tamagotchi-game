package com.example.tamagotchi.model

enum class Weather { CLEAR, RAIN, WIND }
enum class DayTime { DAY, NIGHT }
