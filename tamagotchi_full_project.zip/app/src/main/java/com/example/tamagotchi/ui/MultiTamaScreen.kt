package com.example.tamagotchi.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.tamagotchi.model.Pet
import com.example.tamagotchi.notifications.ReminderScheduler
import com.example.tamagotchi.viewmodel.MultiTamagotchiViewModel

@Composable
fun MultiTamaScreen(vm: MultiTamagotchiViewModel, onExport: ()->Unit, onImport: ()->Unit) {
    val pets = vm.pets
    val selectedIndex = vm.selectedIndex
    val context = LocalContext.current

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        LazyRow {
            itemsIndexed(pets) { idx, pet ->
                Card(modifier = Modifier.padding(6.dp).size(110.dp).clickable { vm.select(idx) },
                    backgroundColor = if (idx == selectedIndex) Color(0xFFDDEEFF) else MaterialTheme.colors.surface) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text(pet.name, style = MaterialTheme.typography.subtitle1)
                        Spacer(Modifier.height(6.dp))
                        Text("H:${'$'}{pet.hunger}")
                        Text("E:${'$'}{pet.energy}")
                    }
                }
            }
            item {
                Card(modifier = Modifier.padding(6.dp).size(110.dp).clickable { vm.addPet("Тама${'$'}{(1..999).random()}") },
                    backgroundColor = MaterialTheme.colors.primary) {
                    Box(contentAlignment = Alignment.Center) { Text("+") }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        val pet = vm.selectedPet
        if (pet != null) {
            // simplified pet card
            Card(modifier = Modifier.fillMaxWidth().height(220.dp)) {
                Column(modifier = Modifier.fillMaxSize().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(modifier = Modifier.size(120.dp).clip(CircleShape).background(Color(0xFFFFC107)), contentAlignment = Alignment.Center) {
                        Text(pet.appearance.faceEmoji)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(pet.name + " — " + pet.personality.name)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Text("H:${'$'}{pet.hunger}")
                        Text("S:${'$'}{pet.happiness}")
                        Text("E:${'$'}{pet.energy}")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row {
                        Button(onClick = { vm.feedSelected() }) { Text("Кормить") }
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { vm.playSelected() }) { Text("Играть") }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Coins: ${'$'}{pet.coins}  Level: ${'$'}{pet.level} XP: ${'$'}{pet.xp}")
                }
            }

            Spacer(Modifier.height(12.dp))
            Row {
                Button(onClick = { val new = (pet.reminderHours + 1).coerceAtMost(24); vm.setReminderHoursForSelected(new); if (new>0) ReminderScheduler.schedule(context, vm.selectedPet!!); else ReminderScheduler.cancel(context, vm.selectedPet!!.id) }) { Text("+1ч") }
                Spacer(Modifier.width(8.dp))
                Button(onClick = { vm.resetSelected() }) { Text("Reset") }
            }
        }

        Spacer(Modifier.weight(1f))

        Row {
            Button(onClick = onExport) { Text("Экспорт") }
            Spacer(Modifier.width(8.dp))
            Button(onClick = onImport) { Text("Импорт") }
        }
    }
}
