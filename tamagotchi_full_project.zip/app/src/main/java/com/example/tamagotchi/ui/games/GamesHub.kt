package com.example.tamagotchi.ui.games

import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.tamagotchi.viewmodel.MultiTamagotchiViewModel

@Composable
fun GamesHub(vm: MultiTamagotchiViewModel, onClose: ()->Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Button(onClick = { /* navigate to Jump */ }, modifier = Modifier.fillMaxWidth()) { Text("Прыжки") }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { /* navigate to Catch */ }, modifier = Modifier.fillMaxWidth()) { Text("Ловля монет") }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { /* navigate to Puzzle */ }, modifier = Modifier.fillMaxWidth()) { Text("Пазл 3x3") }
        Spacer(Modifier.weight(1f))
        Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Назад") }
    }
}
