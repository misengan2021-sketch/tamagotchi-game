package com.example.tamagotchi.data

import android.content.Context
import android.content.SharedPreferences
import com.example.tamagotchi.model.Pet
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class PetsRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("tama_prefs_multi", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val listType = object : TypeToken<List<Pet>>() {}.type

    fun loadAll(): MutableList<Pet> {
        val json = prefs.getString("pets_json", null) ?: return mutableListOf()
        return try {
            gson.fromJson<List<Pet>>(json, listType).toMutableList()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun saveAll(pets: List<Pet>) {
        val json = gson.toJson(pets)
        prefs.edit().putString("pets_json", json).apply()
    }

    fun exportJson(pets: List<Pet>): String = gson.toJson(pets)

    fun importFromJson(json: String): List<Pet> {
        val imported = try {
            gson.fromJson<List<Pet>>(json, listType) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
        val current = loadAll()
        val map = (current + imported).associateBy { it.id }.toMutableMap()
        val merged = map.values.toList()
        saveAll(merged)
        return merged
    }
}
