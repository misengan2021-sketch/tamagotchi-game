package com.example.tamagotchi.data

import com.example.tamagotchi.model.*

object ShopRepository {
    val items = listOf(
        ShopItem("apple", "Яблоко", 5, ShopCategory.FOOD, hungerRestore = 10),
        ShopItem("meat", "Мясо", 12, ShopCategory.FOOD, hungerRestore = 25),
        ShopItem("ball", "Мячик", 20, ShopCategory.TOY, happinessBoost = 15),
        ShopItem("bed", "Мягкая кровать", 70, ShopCategory.DECOR, happinessBoost = 25),
        ShopItem("plant", "Комнатное растение", 40, ShopCategory.DECOR, happinessBoost = 10)
    )
}
