package com.example.tamagotchi.model

enum class PetType(val displayName: String) {
    CAT("Кот"),
    DOG("Пёс"),
    DRAGON("Дракон"),
    HORSE("Лошадь")
}
