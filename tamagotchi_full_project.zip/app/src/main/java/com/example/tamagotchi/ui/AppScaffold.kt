package com.example.tamagotchi.ui

import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.*
import androidx.compose.ui.unit.dp

@Composable
fun MainApp(vm: com.example.tamagotchi.viewmodel.MultiTamagotchiViewModel, onImport: ()->Unit) {
    var screen by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("home") }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Tamagotchi — полный проект") })
    }) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when(screen) {
                "home" -> com.example.tamagotchi.ui.MultiTamaScreen(vm = vm,
                    onExport = { /* TODO */ }, onImport = onImport)
                "shop" -> com.example.tamagotchi.ui.ShopScreen(vm = vm, onClose = { screen = "home" })
                "games" -> com.example.tamagotchi.ui.games.GamesHub(vm = vm, onClose = { screen = "home" })
            }
            BottomNavigation {
                BottomNavigationItem(selected = screen=="home", onClick = { screen = "home" }, icon = {}, label = { Text("Дом") })
                BottomNavigationItem(selected = screen=="shop", onClick = { screen = "shop" }, icon = {}, label = { Text("Магазин") })
                BottomNavigationItem(selected = screen=="games", onClick = { screen = "games" }, icon = {}, label = { Text("Игры") })
            }
        }
    }
}
