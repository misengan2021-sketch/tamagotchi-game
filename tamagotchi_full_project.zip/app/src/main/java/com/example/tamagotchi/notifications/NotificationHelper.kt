package com.example.tamagotchi.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.tamagotchi.R

object NotificationHelper {
    const val CHANNEL_ID = "tamagotchi_channel"
    const val CHANNEL_NAME = "Tamagotchi Notifications"

    fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Напоминания о питомцах"
            }
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(ch)
        }
    }

    fun showNotification(ctx: Context, notificationId: Int, title: String, text: String) {
        val builder = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_name)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)

        with(NotificationManagerCompat.from(ctx)) {
            notify(notificationId, builder.build())
        }
    }
}
