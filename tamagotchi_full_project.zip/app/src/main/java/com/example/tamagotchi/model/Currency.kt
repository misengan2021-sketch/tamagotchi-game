package com.example.tamagotchi.model

data class Currency(var coins: Int = 0)
