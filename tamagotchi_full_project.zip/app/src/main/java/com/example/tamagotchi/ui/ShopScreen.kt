package com.example.tamagotchi.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.tamagotchi.data.ShopRepository
import com.example.tamagotchi.viewmodel.MultiTamagotchiViewModel

@Composable
fun ShopScreen(vm: MultiTamagotchiViewModel, onClose: () -> Unit) {
    val items = ShopRepository.items
    val pet = vm.selectedPet ?: return

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Монеты: ${'$'}{pet.coins}", style = MaterialTheme.typography.h6)
        Spacer(Modifier.height(10.dp))
        LazyColumn {
            items(items.size) { idx ->
                val item = items[idx]
                Row(modifier = Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(item.name)
                    Row {
                        Text("${'$'}{item.price}💰", modifier = Modifier.alignByBaseline())
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { vm.buyItem(item) }) { Text("Купить") }
                    }
                }
                Divider()
            }
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Закрыть") }
    }
}
