package com.example.tamagotchi.model

enum class Location(val displayName: String) {
    HOME("Дом"),
    PARK("Парк"),
    BEACH("Пляж"),
    FOREST("Лес"),
    KITCHEN("Кухня")
}
