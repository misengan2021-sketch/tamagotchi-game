package com.example.tamagotchi.model

data class Appearance(
    val baseColorHex: String = "#FFC107",
    val faceEmoji: String = "😊",
    val accessory: String? = null
)

enum class Personality { PLAYFUL, LAZY, GREEDY, SHY }

data class Pet(
    val id: String,
    val name: String = "Тама",
    val createdAt: Long = System.currentTimeMillis(),
    val ageSeconds: Long = 0,
    val hunger: Int = 80,
    val happiness: Int = 80,
    val energy: Int = 80,
    val alive: Boolean = true,
    val reminderHours: Int = 0,
    val personality: Personality = Personality.PLAYFUL,
    val appearance: Appearance = Appearance(),
    val foodHistory: List<String> = emptyList(),
    val coins: Int = 50,
    val level: Int = 1,
    val xp: Int = 0,
    val type: PetType = PetType.CAT,
    var location: Location = Location.HOME
)
