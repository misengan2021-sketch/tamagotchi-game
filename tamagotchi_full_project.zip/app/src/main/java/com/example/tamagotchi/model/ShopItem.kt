package com.example.tamagotchi.model

enum class ShopCategory { FOOD, TOY, DECOR }

data class ShopItem(
    val id: String,
    val name: String,
    val price: Int,
    val category: ShopCategory,
    val hungerRestore: Int = 0,
    val happinessBoost: Int = 0
)
